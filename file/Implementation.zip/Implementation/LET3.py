import math, random, os, time, shutil, string, sys

#clusternum = 0
#for i in os.walk('/home/seitest/chenjj/compiler/ours/machine_learning/cluster/test/X-means_5_20_1000'):
clusternum = len(os.listdir('./prob/'))###
start = time.time()
print clusternum

maxproblists = [[] for i in range(clusternum)]
maxnamelists = [[] for i in range(clusternum)]

for i in range(0, clusternum):
	filepath = os.path.join('./prob/', 'cluster' + str(i) +'.txt')
	filecluster = open(filepath)
	for line in filecluster.xreadlines():
		nPos = line.index('=')

		maxnamelists[i].append(line[0:(nPos - 1)])
		maxproblists[i].append(string.atof(line[(nPos + 2):]))

allclustermaxproblist = []
allclusterindex = []

sumprob = 0
for j in range(0, clusternum):
	allclusterindex.append(0)
	allclustermaxproblist.append(maxproblists[j][0])
	sumprob += maxproblists[j][0]

distribution = []
distrib = 0
for k in range(0, clusternum):
	distrib += allclustermaxproblist[k]/sumprob
	distribution.append(distrib)

for cnt in range(0, 84593):#####

	start = time.time()

	rnd = random.uniform(0, 1)
	for index in range(0, clusternum):
		if(distribution[index] > rnd):
			while(distribution[index] == 0):
				index -= 1
			selectedcluster = index

			rnd1 = random.randint(0, len(maxproblists[selectedcluster]) - 1)

			selectedfilename = maxnamelists[selectedcluster][rnd1]
			selectedfileprob = maxproblists[selectedcluster][rnd1]
			# selectedfilename = maxnamelists[selectedcluster][0]
			# selectedfileprob = maxproblists[selectedcluster][0]
			#selectedpath = '/SEIDISK/chenjj/compiler/clusterspeedup/test/gcc443allfiles/cluster/wheelselection1/X-means_3_10_2000_all_afterdelete/cluster' + str(selectedcluster) + '/' + selectedfilename
			#print selectedpath

			

			sumprob -= allclustermaxproblist[selectedcluster]
			del maxnamelists[selectedcluster][rnd1]
			del maxproblists[selectedcluster][rnd1]
			if(len(maxproblists[selectedcluster]) == 0):
				allclustermaxproblist[selectedcluster] = 0
			else:
				allclustermaxproblist[selectedcluster] = maxproblists[selectedcluster][0]
			sumprob += allclustermaxproblist[selectedcluster]
			
			distribution = []
			distrib = 0
			for newk in range(0, clusternum):
				distrib += allclustermaxproblist[newk]/sumprob
				distribution.append(distrib)

			#os.system("cp " + selectedpath + " /home/seitest/chenjj/compiler/ours/machine_learning/cluster/test/csmith-2.2.0/runtime")
			
			#os.system("sh run_cluster.sh " + selectedfilename[:-2])
			
			fselectedfilenameorder = file(sys.argv[1],'a+')
			fselectedfilenameorder.write(selectedfilename + "\n")


			end = time.time()
			elapsed = end - start

			ftime = file('selectiontime_' + sys.argv[1],'a+')
			ftime.write(str(elapsed) + "\n")

			fcluster = file('clusterselected_' + sys.argv[1],'a+')
			fcluster.write(str(selectedcluster) + "---" + selectedfilename + "---" + str(selectedfileprob) + "\n")

			fcluster.close()
			ftime.close()
			fselectedfilenameorder.close()
			break



os.system("python dicttime.py " + sys.argv[1] + " " + sys.argv[2])
os.system("python distinguishcluster.py " + sys.argv[1] + " " + sys.argv[2])

