import math, random, os, time, shutil, string, sys

start = time.time()
order = open("prob_order.csv")
for line in order.xreadlines():
	nPos = line.index(' = ')
	filename = line[:nPos]
	# print filename

	# selectedpath = '/SEIDISK/chenjj/compiler/clusterspeedup/test/onlyclassification/programs/' + filename 

	# os.system("cp " + selectedpath + " /SEIDISK/chenjj/compiler/clusterspeedup/test/onlyclassification/csmith-2.2.0/runtime")
			
	# os.system("./run_cluster.sh " + filename[:-2])
	end = time.time()
	elapsed = end - start

	fselectedfilenameorder = file(sys.argv[1],'a+')
	fselectedfilenameorder.write(filename + "\n")

	ftime = file('selectiontime_' + sys.argv[1],'a+')
	ftime.write(str(elapsed) + "\n")

fselectedfilenameorder .close()
ftime.close()

os.system("python dicttime.py " + sys.argv[1] + " " + sys.argv[2])
os.system("python distinguishcluster.py " + sys.argv[1] + " " + sys.argv[2])